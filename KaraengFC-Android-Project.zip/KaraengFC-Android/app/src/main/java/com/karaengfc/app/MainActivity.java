package com.karaengfc.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + HOST + "/assets/index.html";
    private static final int PICK_FILE = 41;
    private static final String REPO = "yudib27fjr-a11y/Karaeng-Score";
    static final int NATIVE_VERSION = 4;
    private static final Pattern WEB_VER = Pattern.compile("karaeng-web-version\" content=\"(\\d+)\"");
    private long lastCheck = 0;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);

        final WebViewAssetLoader.AssetsPathHandler assets = new WebViewAssetLoader.AssetsPathHandler(this);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", path -> {
                    if ("index.html".equals(path) || path.isEmpty()) {
                        File f = cachedWeb();
                        if (f.exists() && cachedVersion() > assetVersion()) {
                            try {
                                return new WebResourceResponse("text/html", "utf-8", new FileInputStream(f));
                            } catch (Exception ignored) {
                            }
                        }
                    }
                    return assets.handle(path);
                })
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (HOST.equals(uri.getHost())) return false;
                openExternal(uri);
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                String[] types = params.getAcceptTypes();
                String type = (types != null && types.length > 0 && types[0] != null && types[0].contains("/")) ? types[0] : "*/*";
                pick.setType(type);
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(pick, "Pilih file"), PICK_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        if (state != null) web.restoreState(state);
        else web.loadUrl(HOME);
        web.postDelayed(() -> checkUpdates(false), 4000);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null && lastCheck > 0) checkUpdates(false);
    }

    private File cachedWeb() {
        return new File(new File(getFilesDir(), "web"), "index.html");
    }

    private static long versionOf(byte[] head) {
        Matcher m = WEB_VER.matcher(new String(head, StandardCharsets.UTF_8));
        return m.find() ? Long.parseLong(m.group(1)) : 0;
    }

    private static byte[] readHead(InputStream in) throws IOException {
        byte[] b = new byte[32768];
        int n = 0, r;
        while (n < b.length && (r = in.read(b, n, b.length - n)) > 0) n += r;
        return Arrays.copyOf(b, n);
    }

    private long assetVersion() {
        try (InputStream in = getAssets().open("index.html")) {
            return versionOf(readHead(in));
        } catch (Exception e) {
            return 0;
        }
    }

    private long cachedVersion() {
        File f = cachedWeb();
        if (!f.exists()) return 0;
        try (InputStream in = new FileInputStream(f)) {
            return versionOf(readHead(in));
        } catch (Exception e) {
            return 0;
        }
    }

    private static byte[] download(String u, int max) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setInstanceFollowRedirects(true);
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setUseCaches(false);
        int code = c.getResponseCode();
        if (code != 200) throw new IOException("HTTP " + code);
        try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[16384];
            int r;
            while ((r = in.read(buf)) > 0) {
                out.write(buf, 0, r);
                if (out.size() > max) throw new IOException("file terlalu besar");
            }
            return out.toByteArray();
        } finally {
            c.disconnect();
        }
    }

    private void js(String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    private void checkUpdates(final boolean manual) {
        long now = System.currentTimeMillis();
        if (!manual && now - lastCheck < 20 * 60 * 1000) return;
        lastCheck = now;
        new Thread(() -> {
            boolean found = false;
            try {
                byte[] data = download("https://github.com/" + REPO + "/releases/latest/download/index.html", 16_000_000);
                long v = versionOf(Arrays.copyOf(data, Math.min(data.length, 32768)));
                long cur = Math.max(assetVersion(), cachedVersion());
                if (v > cur && new String(data, StandardCharsets.UTF_8).contains("AndroidBridge")) {
                    File dir = cachedWeb().getParentFile();
                    if (dir != null) dir.mkdirs();
                    File tmp = new File(dir, "index.tmp");
                    try (FileOutputStream o = new FileOutputStream(tmp)) {
                        o.write(data);
                    }
                    File target = cachedWeb();
                    if (!tmp.renameTo(target)) {
                        target.delete();
                        tmp.renameTo(target);
                    }
                    found = true;
                    js("window.onAppUpdate&&onAppUpdate(" + v + ")");
                }
            } catch (Exception ignored) {
            }
            try {
                byte[] nv = download("https://github.com/" + REPO + "/releases/latest/download/native-version.txt", 1000);
                int n = Integer.parseInt(new String(nv, StandardCharsets.UTF_8).trim());
                if (n > NATIVE_VERSION) {
                    found = true;
                    js("window.onApkUpdate&&onApkUpdate('https://github.com/" + REPO + "/releases/latest')");
                }
            } catch (Exception ignored) {
            }
            if (manual && !found) js("window.onNoUpdate&&onNoUpdate()");
        }).start();
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception e) {
            toast("Tidak ada aplikasi untuk membuka tautan ini");
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_FILE && fileCallback != null) {
            Uri[] picked = null;
            if (resultCode == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null && clip.getItemCount() > 0) {
                    picked = new Uri[clip.getItemCount()];
                    for (int k = 0; k < clip.getItemCount(); k++) picked[k] = clip.getItemAt(k).getUri();
                } else if (data.getData() != null) {
                    picked = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(picked);
            fileCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private String saveBytes(String name, byte[] data, String mime) throws Exception {
        boolean image = mime.startsWith("image/");
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            String folder = (image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS) + "/Karaeng FC";
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, folder);
            Uri target = image ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            Uri uri = getContentResolver().insert(target, cv);
            if (uri == null) throw new Exception("tidak bisa membuat file");
            try (OutputStream o = getContentResolver().openOutputStream(uri)) {
                o.write(data);
            }
            return folder;
        } else {
            File dir = getExternalFilesDir(image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS);
            if (dir == null) dir = getFilesDir();
            dir.mkdirs();
            try (FileOutputStream o = new FileOutputStream(new File(dir, name))) {
                o.write(data);
            }
            return dir.getAbsolutePath();
        }
    }

    private class Bridge {
        @JavascriptInterface
        public void saveFile(final String name, final String b64, final String mime) {
            runOnUiThread(() -> {
                try {
                    String where = saveBytes(name, Base64.decode(b64, Base64.DEFAULT), mime);
                    toast("Tersimpan di " + where + ": " + name);
                } catch (Exception e) {
                    toast("Gagal menyimpan: " + e.getMessage());
                }
            });
        }

        @JavascriptInterface
        public void shareFile(final String name, final String b64, final String mime, final String text) {
            runOnUiThread(() -> {
                try {
                    File dir = new File(getCacheDir(), "shared");
                    dir.mkdirs();
                    File f = new File(dir, name);
                    try (FileOutputStream o = new FileOutputStream(f)) {
                        o.write(Base64.decode(b64, Base64.DEFAULT));
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, "com.karaengfc.app.files", f);
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType(mime);
                    i.putExtra(Intent.EXTRA_STREAM, uri);
                    if (text != null && !text.isEmpty()) i.putExtra(Intent.EXTRA_TEXT, text);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(i, "Bagikan"));
                } catch (Exception e) {
                    toast("Gagal membagikan: " + e.getMessage());
                }
            });
        }

        @JavascriptInterface
        public void reload() {
            runOnUiThread(() -> web.reload());
        }

        @JavascriptInterface
        public void checkUpdate() {
            checkUpdates(true);
        }

        @JavascriptInterface
        public String appInfo() {
            return "{\"native\":" + NATIVE_VERSION + ",\"web\":" + Math.max(assetVersion(), cachedVersion()) + "}";
        }

        @JavascriptInterface
        public void copyText(final String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Karaeng FC", text));
            });
        }
    }
}
